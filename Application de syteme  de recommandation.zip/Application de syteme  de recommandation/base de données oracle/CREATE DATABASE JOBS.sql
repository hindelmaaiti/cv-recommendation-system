CREATE DATABASE JOBS;
USE JOBS;

-- 1. Table DOMAINE
CREATE TABLE DOMAINE (
    id_domaine INT PRIMARY KEY AUTO_INCREMENT,
    nom_domaine VARCHAR(100) NOT NULL,
    CONSTRAINT uk_nom_domaine UNIQUE (nom_domaine)
);

-- 2. Table SPECIALITE
CREATE TABLE SPECIALITE (
    id_specialite INT PRIMARY KEY AUTO_INCREMENT,
    nom_specialite VARCHAR(100) NOT NULL,
    id_domaine INT NOT NULL,
    CONSTRAINT uk_specialite_domaine UNIQUE (nom_specialite, id_domaine),
    FOREIGN KEY (id_domaine) REFERENCES DOMAINE(id_domaine)
);

-- 3. Table METIER
CREATE TABLE METIER (
    id_metier INT PRIMARY KEY AUTO_INCREMENT,
    nom_metier VARCHAR(100) NOT NULL,
    id_specialite INT NOT NULL,
    CONSTRAINT uk_metier_specialite UNIQUE (nom_metier, id_specialite),
    FOREIGN KEY (id_specialite) REFERENCES SPECIALITE(id_specialite)
);

-- 4. Table REGION
CREATE TABLE REGION (
    id_region INT PRIMARY KEY AUTO_INCREMENT,
    nom_region VARCHAR(100) NOT NULL,
    CONSTRAINT uk_nom_region UNIQUE (nom_region)
);

-- 5. Table OFFRE_EMPLOI
CREATE TABLE OFFRE_EMPLOI (
    id_offre INT PRIMARY KEY AUTO_INCREMENT,
    titre VARCHAR(200) NOT NULL,
    date_offre DATE,
    entreprise VARCHAR(100),
    id_metier INT,
    id_region INT,
    description TEXT,
    source_site VARCHAR(100),
    url VARCHAR(255),  -- Ajout recommandé
    CONSTRAINT fk_metier FOREIGN KEY (id_metier) REFERENCES METIER(id_metier),
    CONSTRAINT fk_region FOREIGN KEY (id_region) REFERENCES REGION(id_region)
);

-- 6. Table COMPETENCE
CREATE TABLE COMPETENCE (
    id_competence INT PRIMARY KEY AUTO_INCREMENT,
    nom_competence VARCHAR(100) NOT NULL,
    CONSTRAINT uk_nom_competence UNIQUE (nom_competence)
);

-- 7. Table COMPETENCE_OFFRE
CREATE TABLE COMPETENCE_OFFRE (
    id_offre INT NOT NULL,
    id_competence INT NOT NULL,
    PRIMARY KEY (id_offre, id_competence),
    CONSTRAINT fk_offre FOREIGN KEY (id_offre) REFERENCES OFFRE_EMPLOI(id_offre),
    CONSTRAINT fk_competence_offre FOREIGN KEY (id_competence) REFERENCES COMPETENCE(id_competence)
);

-- 8. Table COMPETENCE_METIER
CREATE TABLE COMPETENCE_METIER (
    id_metier INT NOT NULL,
    id_competence INT NOT NULL,
    niveau_recommande VARCHAR(50),
    PRIMARY KEY (id_metier, id_competence),
    CONSTRAINT fk_metier_competence FOREIGN KEY (id_metier) REFERENCES METIER(id_metier),
    CONSTRAINT fk_competence_metier FOREIGN KEY (id_competence) REFERENCES COMPETENCE(id_competence)
);

-- 9. Table COMPETENCE_SPECIALITE
CREATE TABLE COMPETENCE_SPECIALITE (
    id_specialite INT NOT NULL,
    id_competence INT NOT NULL,
    PRIMARY KEY (id_specialite, id_competence),
    CONSTRAINT fk_specialite FOREIGN KEY (id_specialite) REFERENCES SPECIALITE(id_specialite),
    CONSTRAINT fk_competence_specialite FOREIGN KEY (id_competence) REFERENCES COMPETENCE(id_competence)
);

-- 10. Table PREDICTION_METIER
CREATE TABLE PREDICTION_METIER (
    id_prediction INT PRIMARY KEY AUTO_INCREMENT,
    id_region INT NOT NULL,
    id_metier INT NOT NULL,
    annee INT NOT NULL,
    score_pred FLOAT,
    CONSTRAINT uk_prediction UNIQUE (id_region, id_metier, annee),
    CONSTRAINT fk_pred_region FOREIGN KEY (id_region) REFERENCES REGION(id_region),
    CONSTRAINT fk_pred_metier FOREIGN KEY (id_metier) REFERENCES METIER(id_metier)
);