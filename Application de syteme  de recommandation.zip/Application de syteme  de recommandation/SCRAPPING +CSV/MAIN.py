import os

print("➡️ Running Hind Scraper...")
os.system('python C:\\Users\\imane\\OneDrive\\Documents\\APPSQL\\SCRAPPING\\HIND_SCRAPER.py')

print("➡️ Running Meryem Scraper...")
os.system('python C:\\Users\\imane\\OneDrive\\Documents\\APPSQL\\SCRAPPING\\MERYEM_SCRAPER.py')

print("➡️ Running Imane Scraper...")
os.system('python C:\\Users\\imane\\OneDrive\\Documents\\APPSQL\\SCRAPPING\\IMANE_SCRAPER.py')

print("➡️ Running Oumayma Scraper...")
os.system('python C:\\Users\\imane\\OneDrive\\Documents\\APPSQL\\SCRAPPING\\OUMAYMA_SCRAPER.py')


print("✅scrapers finished and saved into jobs.csv")
