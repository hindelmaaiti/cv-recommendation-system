import oracledb

def get_connection():
    return oracledb.connect(
        user="JOBS",
        password="job2025",
        dsn="127.0.0.1/orcl"
    )
    cursor = connection.cursor()
